# AI News Scraper & Auto Blogger Pro - API

यह API AI News Scraper & Auto Blogger Pro WordPress प्लगइन के लिए बैकएंड सेवाएँ प्रदान करती है।

## Heroku पर होस्टिंग

1. [Heroku](https://www.heroku.com/) पर खाता बनाएँ (यदि आपके पास पहले से नहीं है)
2. Heroku CLI इंस्टॉल करें
3. निम्न कमांड चलाएं:

```bash
# लॉगिन करें
heroku login

# API डायरेक्टरी में जाएं
cd /path/to/ai-news-scraper-auto-blogger-pro/api

# नया Heroku ऐप बनाएं
heroku create your-app-name

# ऐप को डिप्लॉय करें
git init
git add .
git commit -m "Initial commit"
git push heroku main

# आवश्यक एनवायरनमेंट वेरिएबल सेट करें
heroku config:set OPENAI_API_KEY=your_openai_api_key
```

4. अपने WordPress प्लगइन सेटिंग्स में, API URL को `https://your-app-name.herokuapp.com` पर सेट करें

## Vercel पर होस्टिंग

1. [Vercel](https://vercel.com/) पर खाता बनाएँ
2. इस रिपॉजिटरी को अपने GitHub खाते पर फोर्क या क्लोन करें
3. Vercel डैशबोर्ड पर "New Project" पर क्लिक करें
4. अपने GitHub रिपॉजिटरी को आयात करें
5. निम्न सेटिंग्स कॉन्फ़िगर करें:
   - Framework Preset: Other
   - Root Directory: api
   - Build Command: pip install -r requirements.txt
   - Output Directory: .
6. एनवायरनमेंट वेरिएबल में OPENAI_API_KEY जोड़ें
7. "Deploy" पर क्लिक करें
8. अपने WordPress प्लगइन सेटिंग्स में, API URL को Vercel द्वारा प्रदान किए गए URL पर सेट करें

## डेवलपमेंट

लोकल डेवलपमेंट के लिए:

```bash
# आवश्यक पैकेज इंस्टॉल करें
pip install -r requirements.txt

# सर्वर चलाएं
python main.py
```

सर्वर डिफ़ॉल्ट रूप से http://0.0.0.0:5000 पर चलेगा।